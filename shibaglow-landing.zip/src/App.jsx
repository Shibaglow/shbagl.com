import React from 'react';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import Sponsors from './components/Sponsors';
import Tokenomics from './components/Tokenomics';
import Roadmap from './components/Roadmap';

function App() {
  return (
    <div className="bg-[#1a0e03] text-white">
      <Navbar />
      <HeroSection />
      <Sponsors />
      <Tokenomics />
      <Roadmap />
    </div>
  );
}

export default App;
