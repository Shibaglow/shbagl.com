import React from 'react';

const Navbar = () => {
  return (
    <nav className="flex justify-between items-center px-6 py-4 bg-[#1a0e03] border-b border-orange-500">
      <div className="flex items-center space-x-3">
        <img src="/logo.png" alt="ShibaGlow" className="w-10 h-10" />
        <span className="font-bold text-xl">ShibaGlow</span>
      </div>
      <ul className="hidden md:flex space-x-6 font-semibold">
        <li>Home</li>
        <li>Introduction</li>
        <li>Sponsors</li>
        <li>Tokenomics</li>
        <li>Roadmap</li>
        <li>Holders’ Benefits</li>
      </ul>
      <button className="bg-white text-black px-4 py-2 rounded-md font-bold">WHITEPAPER</button>
    </nav>
  );
};

export default Navbar;
