import React from 'react';

const Tokenomics = () => {
  return (
    <section className="px-6 py-16 bg-[#1a0e03] text-center">
      <h2 className="text-3xl font-bold mb-6">Tokenomics</h2>
      <p className="mb-6">1 Trillion $GLOW</p>
      <div className="flex flex-col items-center md:flex-row md:justify-center md:space-x-10">
        <img src="/chart.png" alt="Tokenomics Chart" className="w-64 h-64 mb-6 md:mb-0" />
        <ul className="text-left space-y-2">
          <li><span className="text-green-400 font-bold">40%</span> Holder Rewards (Reflections)</li>
          <li><span className="text-blue-400 font-bold">30%</span> Liquidity Pool (Locked 5 Yrs)</li>
          <li><span className="text-orange-400 font-bold">15%</span> Marketing & Growth</li>
          <li><span className="text-purple-400 font-bold">10%</span> Development Fund</li>
          <li><span className="text-pink-400 font-bold">5%</span> Charity</li>
        </ul>
      </div>
      <div className="mt-6 text-sm text-gray-300">
        <p>Transaction Fees:</p>
        <p>• 5% Reflection to holders</p>
        <p>• 2% Liquidity for price stability</p>
        <p>• 1% Charity for global causes</p>
      </div>
    </section>
  );
};

export default Tokenomics;
