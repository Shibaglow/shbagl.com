import React from 'react';

const sponsors = [
  { name: 'FaZe Banks', role: 'Youtuber', img: '/faze.png' },
  { name: 'TJR Trades', role: 'Youtuber', img: '/tjr.png' },
  { name: 'Logan Paul', role: 'Youtuber', img: '/logan.png' },
  { name: 'Davinci Jeremie', role: 'Youtuber', img: '/davinci.png' },
];

const Sponsors = () => {
  return (
    <section className="px-6 py-16 bg-[#2b1a09]">
      <h2 className="text-3xl font-bold text-center mb-8">Our Sponsors</h2>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {sponsors.map((sponsor) => (
          <div key={sponsor.name} className="text-center">
            <img src={sponsor.img} alt={sponsor.name} className="rounded-full w-24 h-24 mx-auto mb-2" />
            <p className="font-semibold">{sponsor.name}</p>
            <p className="text-sm text-gray-400">{sponsor.role}</p>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Sponsors;
