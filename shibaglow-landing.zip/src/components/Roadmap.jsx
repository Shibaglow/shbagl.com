import React from 'react';

const phases = [
  {
    title: 'Phase 1: Launch (Q1 2024)',
    items: [
      'Official Launch on BSC',
      'Liquidity Lock for 5 Years',
      'Community Channels Live',
      'First Burn Event',
    ],
  },
  {
    title: 'Phase 2: Growth (Q2 2024)',
    items: [
      'Listings on PancakeSwap, CoinGecko, and CoinMarketCap',
      'Marketing Campaigns',
      'Community-Voted Charitable Donations',
    ],
  },
  {
    title: 'Phase 3: Expansion (Q3 2024)',
    items: [
      'Launch ShibaGlow Dashboard',
      'Introduce Staking Pools',
      'Begin CEX Listings',
    ],
  },
  {
    title: 'Phase 4: Utility (Q4 2024)',
    items: [
      'Ecosystem Development',
      'Launch NFT Marketplace',
      'Mobile App for Wallet & Staking',
    ],
  },
];

const Roadmap = () => {
  return (
    <section className="px-6 py-16 bg-[#2b1a09]">
      <h2 className="text-3xl font-bold text-center mb-10">Roadmap</h2>
      <div className="space-y-8">
        {phases.map((phase, idx) => (
          <div key={idx} className="bg-[#3b2a18] p-6 rounded-lg shadow-lg">
            <h3 className="text-xl font-semibold text-yellow-300 mb-3">{phase.title}</h3>
            <ul className="list-disc list-inside text-gray-200 space-y-1">
              {phase.items.map((item, index) => (
                <li key={index}>{item}</li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </section>
  );
};

export default Roadmap;
