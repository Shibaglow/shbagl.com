import React from 'react';

const HeroSection = () => {
  return (
    <section className="flex flex-col md:flex-row items-center px-6 py-16">
      <div className="md:w-1/2 space-y-6 text-center md:text-left">
        <h1 className="text-4xl md:text-5xl font-bold leading-tight">
          The Meme Coin for Community, Fun, and Financial Rewards
        </h1>
        <p className="text-lg text-gray-300">
          Fortune Favors the bold: ShibaGlow’s Presale — Turn $100 into $100,000 with ShibaGlow — 
          The 1000x meme coin that’s about to make you laugh all the way to the bank!
        </p>
        <button className="bg-white text-black px-6 py-3 font-bold rounded-md">CONNECT WALLET</button>
      </div>
      <div className="md:w-1/2 mt-10 md:mt-0 flex justify-center">
        <img src="/shiba.png" alt="Shiba mascot" className="w-64 h-auto" />
      </div>
    </section>
  );
};

export default HeroSection;
